"""Step Functions state 2 of process_new_email - asks Amazon Nova Micro (via Bedrock's
Converse API) whether the email fetched by fetch_gmail_message is phishing.
"""
import json
import logging

import boto3

import common

logger = logging.getLogger(__name__)

BEDROCK_MODEL_ID = common.env("BEDROCK_MODEL_ID")

SYSTEM_PROMPT = (
    "You are a security analyst triaging emails for phishing. Given an email's date, "
    "sender, subject and body, decide whether it is a phishing attempt (e.g. impersonation, "
    "suspicious links, urgency/credential-harvesting tactics). "
    "Respond with ONLY a JSON object, no other text, in exactly this shape: "
    '{"is_phishing": true|false, "confidence": "low"|"medium"|"high", "reasoning": "<one sentence>"}'
)

_bedrock = boto3.client("bedrock-runtime")


def handler(event, _context):
    user_message = (
        f"Date: {event.get('date', '')}\n"
        f"From: {event.get('sender', '')}\n"
        f"Subject: {event.get('subject', '')}\n"
        f"Body:\n{event.get('body', '')}"
    )

    response = _bedrock.converse(
        modelId=BEDROCK_MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=[{"role": "user", "content": [{"text": user_message}]}],
        inferenceConfig={"maxTokens": 300, "temperature": 0},
    )

    raw_text = response["output"]["message"]["content"][0]["text"]
    classification = _parse_classification(raw_text)

    logger.info(
        "classify_phishing_email: email_id=%s is_phishing=%s confidence=%s",
        event.get("email_id"),
        classification["is_phishing"],
        classification["confidence"],
    )

    return {
        "user_id": event.get("user_id"),
        "email_id": event.get("email_id"),
        "sender": event.get("sender"),
        "subject": event.get("subject"),
        "classification": classification,
    }


def _parse_classification(raw_text: str) -> dict:
    try:
        start = raw_text.index("{")
        end = raw_text.rindex("}") + 1
        parsed = json.loads(raw_text[start:end])
        return {
            "is_phishing": bool(parsed.get("is_phishing", False)),
            "confidence": parsed.get("confidence", "low"),
            "reasoning": parsed.get("reasoning", ""),
        }
    except (ValueError, json.JSONDecodeError):
        logger.error("classify_phishing_email: could not parse model output: %s", raw_text)
        return {"is_phishing": False, "confidence": "low", "reasoning": "unparseable_model_output"}
